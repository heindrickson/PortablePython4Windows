
@echo off

::======== TEMPLATE SCRIPT TO RUN YOUR APP ==========
:: You probably JUST need to adjust the name of the
:: python program to be called and its parameters
:: (See the RUNPYTHON label, at the end of this script)
::==================================================

setlocal enabledelayedexpansion
@REM Use SCRIPTDIR throughout the code, instead of ~dp0, because if ~dp0 used AFTER a CD, then bad things can happen 
set "SCRIPT_DIR=%~dp0"
set PP4WIN_DIR_NAME=PortablePython4Windows-1.0.2
set "PP4WIN_PATH=%SCRIPT_DIR%%PP4WIN_DIR_NAME%"

:: Trick to get the ESC character to be used with ANSI escape codes
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"

if not exist "%PP4WIN_PATH%" (
    echo %ESC%[31mERROR %ESC%[0m- The PortablePython4Windows folder was NOT found!
    echo Check if any subfolder within "%SCRIPT_DIR%" contains a file named 'last_path.txt'
    echo If you find this file, rename the subfolder to "%PP4WIN_DIR_NAME%" and run this script again.
    echo If you do not find the 'last_path' file, download this application again and reinstall it.
    echo. & goto FIM
)

FOR /F "tokens=2 delims=:" %%A IN ('chcp') DO SET OLD_CP=%%A
echo Console encoding/codepage when this script started: %OLD_CP%

@REM Ensures it is running where this script is located
cd /D "%SCRIPT_DIR%" 
echo Current working folder/directory: "%CD%"
echo.

REM Read the file that was saved when this portable Python instalation was created.
REM Note: The last_path.txt is ALWAYS created/edited in UTF-8, so codepage 65001~utf8  
REM MUST be active while reading it, so that any non-ASCII characters in the folder
REM name stored there are well understood by the test below:
chcp 65001 >nul
set /p last_path=<"%PP4WIN_PATH%\last_path.txt"
REM Restoring the previous codepage...
@chcp %OLD_CP% >nul
REM The content of last_path variable ALREADY comes with quotation marks
if %last_path% EQU "%PP4WIN_PATH%" (
    goto CONTINUA0
)
echo This script is running from a different folder than the one where this PORTABLE
echo installation was originally created... this situation would cause errors.
echo Please run  "%PP4WIN_PATH%\RECONFIGURE-env.cmd"  then run this script again.
echo [If it still does NOT work, then run the CREATE_or_REcreate-env.cmd script.]
echo. & goto FIM

:CONTINUA0
set "THE_ENV_DIR=%PP4WIN_PATH%\Envs\myenv"
echo A virtual environment named 'myenv' will be activated (if it exists in "%SCRIPT_DIR%Envs" folder)

REM Check whether a virtual environment named 'myenv' exists in the Envs folder
if not exist "%THE_ENV_DIR%\Scripts\python.exe" (
    echo %ESC%[31mERROR %ESC%[0m- python.exe was not found in %THE_ENV_DIR%\Scripts
    echo Please run "%PP4WIN_PATH%\CREATE_or_REcreate-env.cmd", 
    echo then run this script again.
    echo. & goto FIM
)

REM Activate the virtual environment named 'myenv'
REM ('call' runs the specified script and KEEPS all variables it has set 
REM  when RETURNING to this console, allowing this CMD script to CONTINUE executing):
call "%THE_ENV_DIR%\Scripts\activate.bat"
if "%VIRTUAL_ENV%" NEQ "%THE_ENV_DIR%" (
    @echo %ESC%[31mERROR %ESC%[0m- Failed to activate the 'myenv' virtual environment using "%THE_ENV_DIR%\Scripts\activate.bat"
    @echo Please run the "%PP4WIN_PATH%\RECONFIGURE-env.cmd" script, then run this script again.
    @echo [If it still does NOT work, then run the "%PP4WIN_PATH%\CREATE_or_REcreate-env.cmd script"]
    @echo. & goto FIM
)

:RUNPYTHON
:: Adjust below just in case this folder has '&' as part of the name, because, 
:: when using CMD /C, strings inside quotation marks MUST have all the '&' replaced by escaped '^&'
:: (unfortunatelly, Windows allow the special char '&' in names, unlike others forbbiden special chars)
:: PS - Things are pretty confusing: Windows ALSO allows the special chars '(', ')' and '=', but these do NOT require an escape!
:: PS2- This fix has to be done ONLY when using 'cmd.exe'; no fix is necessary for 'call' or direct run.
::      Besides, it must NOT be applyed to strings that are NOT surrounded by quotation marks.
set "SCRIPT_DIR_ESCAPED=%SCRIPT_DIR:&=^&%"

:: We also MUST escape the '(' and ')' chars that are eventually part of the path,
:: whenever we use it inside CMD/C string  and inside blocks surrounded by these 2 chars !!
set "SCRIPT_DIR_ESCAPED=%SCRIPT_DIR_ESCAPED:)=^)%"
set "SCRIPT_DIR_ESCAPED=%SCRIPT_DIR_ESCAPED:(=^(%"

REM Run the python program via cmd /c:
cmd /c " CD "%SCRIPT_DIR_ESCAPED%\APP"  & python "src\main.py" "

REM Deactivate the portable virtual environment
call "%THE_ENV_DIR%\Scripts\deactivate.bat"

:FIM
endlocal
pause
exit /b

