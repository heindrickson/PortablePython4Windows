
print("\n")
print("Hello from MyApp!")
print("This is just a template... put your real code here")
print("\n")
